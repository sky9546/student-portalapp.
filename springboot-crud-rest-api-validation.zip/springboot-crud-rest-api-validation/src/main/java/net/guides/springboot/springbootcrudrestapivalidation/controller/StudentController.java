package net.guides.springboot.springbootcrudrestapivalidation.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.guides.springboot.springbootcrudrestapivalidation.exception.ResourceNotFoundException;
import net.guides.springboot.springbootcrudrestapivalidation.model.Student;
import net.guides.springboot.springbootcrudrestapivalidation.repository.StudentRepository;
import net.guides.springboot.springbootcrudrestapivalidation.response.ResponseHandler;

@RestController
@RequestMapping("/api/v1")
public class StudentController {
	@Autowired
	private StudentRepository studentRepository;

//for getting the grade of students in order by 
	@GetMapping("/grade")
	public List<Student> getGrade(){
		
		return studentRepository.tempQuery();
	}

	//for getting request order by name
	@GetMapping("/student")
	public List<Student> getAllEmployees() {
		return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "name"));
	}
	//for getting request order by age
	@GetMapping("/age")
	public List<Student> getAllEmployeesByAge() {
		return studentRepository.findAll(Sort.by(Sort.Direction.ASC, "age"));
	}

	//for getting request with name
	@GetMapping("/{name}")
	public ResponseEntity<Student> getEmployeeById(@PathVariable(value = "name") String studentId)
			throws ResourceNotFoundException {
		Student student = studentRepository.findByName(studentId)
				.orElseThrow(() -> new ResourceNotFoundException("student not found for this name :: " + studentId));
		return ResponseEntity.ok().body(student);
	}

	//for making a post request
	@PostMapping( "/student")
	public ResponseEntity<Object> Post( @RequestBody Student student) {
		
	
		studentRepository.save(student);
		
		

		try {
			Student std = StudentRepository.Post(student);


			return ResponseHandler.generateResponse("Successfully added data!", HttpStatus.OK, std);
		} catch (Exception e) {

			return ResponseHandler.generateResponse(e.getMessage(), HttpStatus.MULTI_STATUS,null);
		}

	}
	//	   @PostMapping("/employees")
	//
	//	   public Employee createEmployee(@Valid @RequestBody Employee employee) {
	//
	//	   return employeeRepository.save(employee);
	//
	//	   }
	
	
	//for updating the record for the selected id
	@PutMapping("/student/{id}")
	public ResponseEntity<Student> updateEmployee(@PathVariable(value = "id") Long studentId,
			@Valid @RequestBody Student studentDetails) throws ResourceNotFoundException {
		Student student = studentRepository.findById(studentId)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + studentId));

		student.setName(studentDetails.getName());
		student.setGrade(studentDetails.getGrade());
		student.setAge(studentDetails.getAge());
		
		final Student updatedStudent = studentRepository.save(student);
		return ResponseEntity.ok(updatedStudent);
	}
	//fo deleting the record for that purticular id only
	@DeleteMapping("/student/{id}")
	public Map<String, Boolean> deleteStudent(@PathVariable(value = "id") Long studentId)
			throws ResourceNotFoundException {
		Student student = studentRepository.findById(studentId)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found for this id :: " + studentId));

		studentRepository.delete(student);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}
}
