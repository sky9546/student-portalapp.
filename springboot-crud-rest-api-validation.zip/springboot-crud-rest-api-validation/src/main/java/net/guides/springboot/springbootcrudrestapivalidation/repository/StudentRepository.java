package net.guides.springboot.springbootcrudrestapivalidation.repository;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import net.guides.springboot.springbootcrudrestapivalidation.model.Student;

@Repository
public interface StudentRepository extends JpaRepository<Student,Long>{

	Optional<Student> findByName(@Valid String studentId);
	static Student Post(Student student) {
		// TODO Auto-generated method stub
		return student;
	}


    @Query(value="SELECT s.id,s.grade,s.name ,s.age FROM studentdetails  s Group by s.Grade,s.name ORDER BY grade ASC", nativeQuery = true)
    public List<Student> tempQuery();

 /*   @Query(value="SELECT s.age FROM studentdetails s ORDER BY age ASC", nativeQuery = true)
    public List<Integer> ageQuery();*/





	

}
