CREATE DATABASE 'demo';
USE demo;

create table users (
	id  int(3) NOT NULL AUTO_INCREMENT,
	name varchar(120) NOT NULL,
	grade varchar(220) NOT NULL,
	age int(5),
	PRIMARY KEY (id)
);

