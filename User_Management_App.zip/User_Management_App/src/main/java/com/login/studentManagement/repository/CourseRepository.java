package com.login.studentManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.login.studentManagement.modal.courseDetails;

public interface CourseRepository extends JpaRepository<courseDetails, Integer> {

	

}