package com.login.studentManagement.modal;

import java.util.Objects;

public class subtracking {
	
	courseDetails course ;
	
	@Override
	public int hashCode() {
		return Objects.hash(course, sub_id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		subtracking other = (subtracking) obj;
		return Objects.equals(course, other.course) && sub_id == other.sub_id;
	}
	public subtracking(courseDetails course, int sub_id) {
		super();
		this.course = course;
		this.sub_id = sub_id;
	}
	public courseDetails getCourse() {
		return course;
	}
	public void setCourse(courseDetails course) {
		this.course = course;
	}
	public int getSub_id() {
		return sub_id;
	}
	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}
	@Override
	public String toString() {
		return "subtracking [course=" + course + ", sub_id=" + sub_id + "]";
	}
	public int sub_id ;

}
