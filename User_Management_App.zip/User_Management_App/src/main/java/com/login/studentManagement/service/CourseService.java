package com.login.studentManagement.service;

import java.util.List;

import com.login.studentManagement.modal.UserDtls;
import com.login.studentManagement.modal.courseDetails;

public interface CourseService {
	
	public courseDetails createCourse(courseDetails course);
	
	public List<courseDetails> getCourse();
	

}
