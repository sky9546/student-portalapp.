package com.login.studentManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.login.studentManagement.modal.*;

public interface SubcriptionRepository extends JpaRepository<SubcriptionDetails, Integer> {
	


	
@Query(
	value= "SELECT s FROM SubcriptionDetails s where s.user_id=?1"	
		)
List<SubcriptionDetails> findByuser_id(int user_id);

@Transactional
@Modifying(clearAutomatically = true)
@Query(
		value= "DELETE FROM SubcriptionDetails s where s.course_id=?1"	
			)
	public void deleteBycourse_id(int course_id);
	}